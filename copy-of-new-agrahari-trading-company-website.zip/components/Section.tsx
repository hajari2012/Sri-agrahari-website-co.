import React from 'react';
import type { SectionProps } from '../types';

const Section: React.FC<SectionProps> = ({ id, className = '', children, style }) => {
  return (
    <section id={id} className={`py-12 md:py-20 ${className}`} style={style}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {children}
      </div>
    </section>
  );
};

export default Section;
