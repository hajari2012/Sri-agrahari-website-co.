
import React from 'react';
import Section from './Section';
import Card from './Card';
import type { SectionProps } from '../types';
import { SERVICES_DATA } from '../constants';

const ServicesSection: React.FC<Pick<SectionProps, 'id'>> = ({ id }) => {
  return (
    <Section id={id} className="bg-gray-100">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Our Services</h2>
        <p className="text-lg text-green-600">Comprehensive Solutions for Rice Bran</p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {SERVICES_DATA.map((service, index) => (
          <Card key={index} className="text-center items-center flex flex-col p-6 h-full">
            <div className="mb-4 p-3 bg-green-100 rounded-full inline-block">
              {service.icon}
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">{service.title}</h3>
            <p className="text-gray-600 text-sm leading-relaxed">{service.description}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
};

export default ServicesSection;
