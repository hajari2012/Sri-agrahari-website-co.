
import React from 'react';

interface CardProps {
  title?: string;
  description?: string;
  imageUrl?: string;
  imageAlt?: string;
  children?: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ title, description, imageUrl, imageAlt, children, className = '' }) => {
  return (
    <div className={`bg-white shadow-lg rounded-xl overflow-hidden transform transition-all hover:scale-105 duration-300 ${className}`}>
      {imageUrl && (
        <img className="w-full h-48 object-cover" src={imageUrl} alt={imageAlt || title || 'Card image'} />
      )}
      <div className="p-6">
        {title && <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>}
        {description && <p className="text-gray-600 text-sm leading-relaxed">{description}</p>}
        {children}
      </div>
    </div>
  );
};

export default Card;
