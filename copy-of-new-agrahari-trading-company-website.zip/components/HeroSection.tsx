
import React from 'react';
import Section from './Section';
import { OWNER_NAME_HINDI, TAGLINE } from '../constants';

const HeroSection: React.FC = () => {
  return (
    <Section id="home" className="bg-cover bg-center bg-no-repeat min-h-[calc(100vh-80px)] md:min-h-screen flex items-center justify-center relative" style={{backgroundImage: "url('https://picsum.photos/seed/ricefield/1600/900')"}}>
      <div className="absolute inset-0 bg-black opacity-50"></div>
      <div className="relative text-center text-white z-10 p-4">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-4">
          Welcome to <span className="text-green-400">{OWNER_NAME_HINDI}</span>
        </h1>
        <p className="text-xl sm:text-2xl md:text-3xl font-hindi mb-6">{TAGLINE}</p>
        <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8">
          Your trusted partner for high-quality rice bran. We specialize in procurement, processing, and supply, ensuring excellence at every step.
        </p>
        <div className="space-x-4">
          <a
            href="#services"
            className="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-8 rounded-lg shadow-md transition duration-300 text-lg"
          >
            Our Services
          </a>
          <a
            href="#contact"
            className="bg-transparent hover:bg-white text-white hover:text-green-700 border-2 border-white font-semibold py-3 px-8 rounded-lg shadow-md transition duration-300 text-lg"
          >
            Contact Us
          </a>
        </div>
      </div>
    </Section>
  );
};

export default HeroSection;
