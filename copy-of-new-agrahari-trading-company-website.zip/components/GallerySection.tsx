
import React from 'react';
import Section from './Section';
import type { SectionProps } from '../types';
import { GALLERY_IMAGES } from '../constants';

const GallerySection: React.FC<Pick<SectionProps, 'id'>> = ({ id }) => {
  return (
    <Section id={id} className="bg-white">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Photo Gallery</h2>
        <p className="text-lg text-green-600">A Glimpse Into Our Operations</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {GALLERY_IMAGES.map((image) => (
          <div key={image.id} className="overflow-hidden rounded-lg shadow-lg aspect-w-4 aspect-h-3 group">
            <img 
              src={image.src} 
              alt={image.alt} 
              className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
             <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300 flex items-end justify-center">
                <p className="text-white text-sm p-2 bg-black bg-opacity-50 rounded-t-md opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  {image.alt}
                </p>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default GallerySection;
