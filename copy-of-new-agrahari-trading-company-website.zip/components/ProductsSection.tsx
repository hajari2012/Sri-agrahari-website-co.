
import React from 'react';
import Section from './Section';
import Card from './Card';
import type { SectionProps } from '../types';
import { PRODUCTS_DATA } from '../constants';

const ProductsSection: React.FC<Pick<SectionProps, 'id'>> = ({ id }) => {
  return (
    <Section id={id} className="bg-white">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Our Products</h2>
        <p className="text-lg text-green-600">High-Quality Processed Rice Bran</p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {PRODUCTS_DATA.map((product, index) => (
          <Card 
            key={index} 
            imageUrl={product.image}
            imageAlt={product.name}
            title={product.name}
            description={product.description}
            className="h-full"
          />
        ))}
      </div>
       <p className="text-center mt-8 text-gray-700">
        We ensure the <strong>best solvent supply bran</strong> through careful processing and quality control.
      </p>
    </Section>
  );
};

export default ProductsSection;
