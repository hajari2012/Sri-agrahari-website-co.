
import React from 'react';
import Section from './Section';
import type { SectionProps } from '../types';
import { CONTACT_INFO, OWNER_NAME } from '../constants';
import WhatsappIcon from './icons/WhatsappIcon';
import PhoneIcon from './icons/PhoneIcon';
import EmailIcon from './icons/EmailIcon';
import LocationIcon from './icons/LocationIcon';

const ContactUsSection: React.FC<Pick<SectionProps, 'id'>> = ({ id }) => {
  return (
    <Section id={id} className="bg-green-50">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Get In Touch</h2>
        <p className="text-lg text-green-700">We're here to help and answer any question you might have.</p>
      </div>
      
      <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-10 bg-white p-8 md:p-12 rounded-xl shadow-2xl">
        {/* Contact Information */}
        <div className="space-y-6">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Contact Information</h3>
          
          <div className="flex items-start">
            <PhoneIcon className="w-6 h-6 text-green-600 mr-4 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-700">Phone</h4>
              <a href={CONTACT_INFO.phoneLink} className="text-green-600 hover:text-green-800 transition-colors">
                {CONTACT_INFO.phone}
              </a>
            </div>
          </div>

          <div className="flex items-start">
            <WhatsappIcon className="w-6 h-6 text-green-600 mr-4 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-700">WhatsApp</h4>
              <a href={CONTACT_INFO.whatsappLink} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:text-green-800 transition-colors">
                Chat with us
              </a>
            </div>
          </div>

          <div className="flex items-start">
            <EmailIcon className="w-6 h-6 text-green-600 mr-4 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-700">Email</h4>
              <a href={CONTACT_INFO.emailLink} className="text-green-600 hover:text-green-800 transition-colors break-all">
                {CONTACT_INFO.email}
              </a>
            </div>
          </div>

          <div className="flex items-start">
            <LocationIcon className="w-6 h-6 text-green-600 mr-4 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-700">Address</h4>
              <p className="text-gray-600">{CONTACT_INFO.address}</p>
              <a href={CONTACT_INFO.mapLink} target="_blank" rel="noopener noreferrer" className="text-sm text-green-600 hover:text-green-800 transition-colors">
                View on Map
              </a>
            </div>
          </div>
           <p className="text-sm text-gray-600 pt-4">
            For inquiries from <span className="font-semibold">Itwa, Bansi, Domariyaganj and surrounding areas</span>, please reach out. We are your trusted field supplier.
          </p>
        </div>

        {/* Placeholder for Contact Form or Map Embed */}
        <div className="bg-gray-100 p-6 rounded-lg flex flex-col items-center justify-center">
            <img 
                src="https://picsum.photos/seed/maplocation/400/300" 
                alt="Map placeholder" 
                className="rounded-lg shadow-md mb-4 w-full object-cover h-64"
            />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">Visit Us or Call</h3>
          <p className="text-gray-600 text-center">
            We welcome you to contact {OWNER_NAME} for all your rice bran needs.
          </p>
        </div>
      </div>
    </Section>
  );
};

export default ContactUsSection;
