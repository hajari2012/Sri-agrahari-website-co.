
import React, { useState, useEffect } from 'react';
import { NAV_LINKS, OWNER_NAME, TAGLINE, BUSINESS_NAME_PRIMARY } from '../constants';
import MenuIcon from './icons/MenuIcon';
import CloseIcon from './icons/CloseIcon';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      id="home"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isMenuOpen ? 'bg-white shadow-lg py-3' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <a href="#home" className="flex flex-col">
          <h1 className={`text-2xl md:text-3xl font-bold ${isScrolled || isMenuOpen ? 'text-green-700' : 'text-white'}`}>{OWNER_NAME}</h1>
          <p className={`text-xs md:text-sm font-hindi ${isScrolled || isMenuOpen ? 'text-green-600' : 'text-gray-200'}`}>{TAGLINE}</p>
          <p className={`text-xs ${isScrolled || isMenuOpen ? 'text-gray-500' : 'text-gray-300'}`}>{BUSINESS_NAME_PRIMARY}</p>
        </a>
        
        <nav className="hidden md:flex space-x-6">
          {NAV_LINKS.map(link => (
            <a 
              key={link.name} 
              href={link.href} 
              className={`font-medium transition-colors ${isScrolled || isMenuOpen ? 'text-gray-700 hover:text-green-600' : 'text-white hover:text-green-300'}`}
            >
              {link.name}
            </a>
          ))}
        </nav>

        <div className="md:hidden">
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)} 
            className={`focus:outline-none ${isScrolled || isMenuOpen ? 'text-gray-700' : 'text-white'}`}
          >
            {isMenuOpen ? <CloseIcon className="w-7 h-7" /> : <MenuIcon className="w-7 h-7" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg py-2">
          <nav className="flex flex-col items-center space-y-3">
            {NAV_LINKS.map(link => (
              <a 
                key={link.name} 
                href={link.href} 
                className="text-gray-700 hover:text-green-600 py-2 w-full text-center"
                onClick={() => setIsMenuOpen(false)} // Close menu on click
              >
                {link.name}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
