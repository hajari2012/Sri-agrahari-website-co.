
import React from 'react';
import Section from './Section';
import type { SectionProps } from '../types';

const TestimonialsSection: React.FC<Pick<SectionProps, 'id'>> = ({ id }) => {
  return (
    <Section id={id} className="bg-gray-100">
      <div className="text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Client Testimonials</h2>
        <p className="text-lg text-green-600 mb-8">What Our Valued Partners Say</p>
        <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-lg">
          <p className="text-gray-700 italic text-center">
            "Testimonials from our satisfied clients and partners will be featured here soon. We pride ourselves on building long-lasting relationships based on trust and quality."
          </p>
          <p className="text-center mt-6 text-gray-500">- The {process.env.REACT_APP_OWNER_NAME || "Hajari Agrahari"} Team</p>
        </div>
      </div>
    </Section>
  );
};

export default TestimonialsSection;
