
import React from 'react';
import Section from './Section';
import type { SectionProps } from '../types';
import { OWNER_NAME, OWNER_NAME_HINDI, BUSINESS_NAME_PRIMARY, BUSINESS_NAME_SECONDARY } from '../constants';

const AboutUsSection: React.FC<Pick<SectionProps, 'id'>> = ({ id }) => {
  return (
    <Section id={id} className="bg-white">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">About Us</h2>
        <p className="text-lg text-green-600 font-semibold font-hindi">{OWNER_NAME_HINDI} - A Legacy of Trust</p>
      </div>
      <div className="grid md:grid-cols-2 gap-10 items-center">
        <div>
          <img 
            src="https://picsum.photos/seed/hajariportrait/600/400" 
            alt={OWNER_NAME} 
            className="rounded-xl shadow-2xl w-full object-cover" 
          />
        </div>
        <div className="text-gray-700 leading-relaxed">
          <p className="mb-4">
            <strong>{OWNER_NAME} ({OWNER_NAME_HINDI})</strong> is a well-respected and trusted name in the local agricultural market of Siddharth Nagar, Uttar Pradesh, particularly known as a premier Rice Bran Trader in UP. With years of dedicated experience, {OWNER_NAME} has built a reputation for reliability, quality, and fair business practices.
          </p>
          <p className="mb-4">
            Our operations are managed under two esteemed firms: <strong>{BUSINESS_NAME_PRIMARY}</strong> (our primary operational entity) and <strong>{BUSINESS_NAME_SECONDARY}</strong>. Together, these firms represent a robust network dedicated to the rice bran industry. We are recognized as a trusted field supplier in the <span className="font-semibold">Itwa, Bansi, Domariyaganj regions</span>.
          </p>
          <p className="mb-4">
            Our core business involves the direct procurement of raw rice bran from rice mill operators. We utilize our own efficient logistics network for transportation to our state-of-the-art processing plant. Here, the raw bran is meticulously filtered and separated into distinct products: fine powder, khandi, and bhusi. These processed goods are then supplied wholesale to solvent extraction plants.
          </p>
          <p className="mb-4">
            While our business is seasonal, typically active for 6-7 months a year, we handle high volumes of trade within this short span. Our commitment is to provide the best solvent supply bran and maintain strong relationships with both our suppliers and customers.
          </p>
        </div>
      </div>
    </Section>
  );
};

export default AboutUsSection;
