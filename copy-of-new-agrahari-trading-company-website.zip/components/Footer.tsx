
import React from 'react';
import { OWNER_NAME, CONTACT_INFO, BUSINESS_NAME_PRIMARY, BUSINESS_NAME_SECONDARY } from '../constants';
import WhatsappIcon from './icons/WhatsappIcon';
import PhoneIcon from './icons/PhoneIcon';
import EmailIcon from './icons/EmailIcon';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-300 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-semibold text-white mb-3">{OWNER_NAME}</h3>
            <p className="text-sm">{BUSINESS_NAME_PRIMARY}</p>
            <p className="text-sm">{BUSINESS_NAME_SECONDARY}</p>
            <p className="mt-2 text-sm font-hindi">{CONTACT_INFO.address}</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white mb-3">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="hover:text-green-400 transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-green-400 transition-colors">About Us</a></li>
              <li><a href="#services" className="hover:text-green-400 transition-colors">Services</a></li>
              <li><a href="#products" className="hover:text-green-400 transition-colors">Products</a></li>
              <li><a href="#contact" className="hover:text-green-400 transition-colors">Contact Us</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white mb-3">Connect With Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <PhoneIcon className="w-5 h-5 mr-3 text-green-400" />
                <a href={CONTACT_INFO.phoneLink} className="hover:text-green-400 transition-colors">{CONTACT_INFO.phone}</a>
              </li>
              <li className="flex items-center">
                <WhatsappIcon className="w-5 h-5 mr-3 text-green-400" />
                <a href={CONTACT_INFO.whatsappLink} target="_blank" rel="noopener noreferrer" className="hover:text-green-400 transition-colors">WhatsApp</a>
              </li>
              <li className="flex items-center">
                <EmailIcon className="w-5 h-5 mr-3 text-green-400" />
                <a href={CONTACT_INFO.emailLink} className="hover:text-green-400 transition-colors break-all">{CONTACT_INFO.email}</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-700 pt-8 text-center">
          <p className="text-sm">&copy; {new Date().getFullYear()} {OWNER_NAME}. All Rights Reserved.</p>
          <p className="text-xs mt-1">Designed with care for a trusted name in rice bran trading.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
